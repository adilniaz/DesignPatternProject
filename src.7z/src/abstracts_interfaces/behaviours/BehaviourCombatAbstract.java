package abstracts_interfaces.behaviours;

public abstract class BehaviourCombatAbstract {
	public abstract String fight();
}
