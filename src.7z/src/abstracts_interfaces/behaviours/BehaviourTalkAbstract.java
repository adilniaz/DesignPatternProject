package abstracts_interfaces.behaviours;

public abstract class BehaviourTalkAbstract {
	public abstract String speak();
}
