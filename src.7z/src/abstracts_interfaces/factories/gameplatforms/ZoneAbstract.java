package abstracts_interfaces.factories.gameplatforms;

public abstract class ZoneAbstract {
	
	public String name;
	public abstract String createZone();
}
