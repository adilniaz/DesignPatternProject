 package abstracts_interfaces.factories.gameplatforms;



public abstract class AccessAbstract {
	
	public String id;
	public abstract String createAccess(ZoneAbstract zone1, ZoneAbstract zone2);
}
