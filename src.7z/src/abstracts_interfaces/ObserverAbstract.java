package abstracts_interfaces;

public abstract class ObserverAbstract {
	public abstract void update();
}
