package abstracts_interfaces.decorators;

public abstract class MountAbstract {
	
}
