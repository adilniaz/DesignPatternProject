package abstracts_interfaces.decorators;

public abstract class ClassSpecialtyAbstract {
	protected String speciality;
}
