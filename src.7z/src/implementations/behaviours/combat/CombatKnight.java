package implementations.behaviours.combat;

import abstracts_interfaces.behaviours.BehaviourCombatAbstract;

public class CombatKnight extends BehaviourCombatAbstract{

	@Override
	public String fight() {
		return "Knights Attack!!";
	}
	
	
}
