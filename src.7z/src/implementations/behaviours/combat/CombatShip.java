package implementations.behaviours.combat;

import abstracts_interfaces.behaviours.BehaviourCombatAbstract;

public class CombatShip extends BehaviourCombatAbstract{

	@Override
	public String fight() {
		return "Ships Attack!!";
	}

}
