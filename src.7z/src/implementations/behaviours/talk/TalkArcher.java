package implementations.behaviours.talk;

import abstracts_interfaces.behaviours.BehaviourTalkAbstract;


public class TalkArcher extends BehaviourTalkAbstract{

	@Override
	public String speak() {
		// TODO Auto-generated method stub
		return "I am an Archer.";
	}

}
