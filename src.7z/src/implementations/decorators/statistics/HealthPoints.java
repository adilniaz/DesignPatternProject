package implementations.decorators.statistics;

import abstracts_interfaces.decorators.StatisticsAbstract;

public class HealthPoints extends StatisticsAbstract{

}
