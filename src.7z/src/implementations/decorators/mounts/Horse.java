package implementations.decorators.mounts;

import abstracts_interfaces.decorators.MountAbstract;

public class Horse extends MountAbstract{

}
