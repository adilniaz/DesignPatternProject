package implementations.decorators.mounts;

import abstracts_interfaces.decorators.MountAbstract;

public class Buggy extends MountAbstract{

}
