package implementations.decorators.classspecialty;

import abstracts_interfaces.decorators.ClassSpecialtyAbstract;

public class LongRange extends ClassSpecialtyAbstract{

}
