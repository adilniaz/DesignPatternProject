package implementations.decorators.classspecialty;

import abstracts_interfaces.decorators.ClassSpecialtyAbstract;

public class AirBourne extends ClassSpecialtyAbstract{

}
