package implementations.decorators.classspecialty;

import abstracts_interfaces.decorators.ClassSpecialtyAbstract;

public class Melee extends ClassSpecialtyAbstract{

}
