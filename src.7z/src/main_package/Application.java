package main_package;


public class Application{
	
	public static void main(String[] args) {
		new GameSimulation();
	}

}
